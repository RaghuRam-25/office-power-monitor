#include <stdio.h>
#include <stdbool.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_adc/adc_oneshot.h"
#include "esp_log.h"
#include "esp_err.h"

static const char *TAG = "WORK_ROOM_1";


#define FAN1_GPIO    GPIO_NUM_17   
#define FAN2_GPIO    GPIO_NUM_16   
#define LIGHT1_GPIO  GPIO_NUM_19   
#define LIGHT2_GPIO  GPIO_NUM_18   
#define LIGHT3_GPIO  GPIO_NUM_21   

#define CURRENT_SENSE_ADC_CHANNEL ADC_CHANNEL_6  

#define RELAY_ON  0
#define RELAY_OFF 1

typedef struct {
    const char *name;
    gpio_num_t pin;
} device_t;

static const device_t devices[] = {
    { "Fan 1",   FAN1_GPIO },
    { "Fan 2",   FAN2_GPIO },
    { "Light 1", LIGHT1_GPIO },
    { "Light 2", LIGHT2_GPIO },
    { "Light 3", LIGHT3_GPIO },
};
#define NUM_DEVICES (sizeof(devices) / sizeof(devices[0]))

static adc_oneshot_unit_handle_t adc_handle;

static void set_device(const device_t *d, bool on) {
    gpio_set_level(d->pin, on ? RELAY_ON : RELAY_OFF);
}

static void init_gpio(void) {
    for (int i = 0; i < NUM_DEVICES; i++) {
        gpio_set_direction(devices[i].pin, GPIO_MODE_OUTPUT);
        gpio_set_level(devices[i].pin, RELAY_OFF);
    }
}

static void init_adc(void) {
    adc_oneshot_unit_init_cfg_t init_config = {
        .unit_id = ADC_UNIT_1,
        .ulp_mode = ADC_ULP_MODE_DISABLE,
    };
    ESP_ERROR_CHECK(adc_oneshot_new_unit(&init_config, &adc_handle));

    adc_oneshot_chan_cfg_t chan_config = {
        .bitwidth = ADC_BITWIDTH_DEFAULT,
        .atten = ADC_ATTEN_DB_12,
    };
    ESP_ERROR_CHECK(adc_oneshot_config_channel(adc_handle, CURRENT_SENSE_ADC_CHANNEL, &chan_config));
}

static int read_current_sense_raw(void) {
    int raw = 0;
    adc_oneshot_read(adc_handle, CURRENT_SENSE_ADC_CHANNEL, &raw);
    return raw;
}

void app_main(void) {
    init_gpio();
    init_adc();

    ESP_LOGI(TAG, "Work Room 1 controller ready: 2 fans, 3 lights, 1 current-sense channel.");
    ESP_LOGI(TAG, "Cycling every device ON/OFF so you can confirm each relay is wired correctly.");
    ESP_LOGI(TAG, "Turn the potentiometer knob while a device is ON to see the ADC value change.");

    while (1) {
        for (int i = 0; i < NUM_DEVICES; i++) {
            set_device(&devices[i], true);
            vTaskDelay(pdMS_TO_TICKS(300));   
            int raw_on = read_current_sense_raw();
            ESP_LOGI(TAG, "%-8s -> ON  | current-sense raw ADC = %d", devices[i].name, raw_on);
            vTaskDelay(pdMS_TO_TICKS(1700));

            set_device(&devices[i], false);
            vTaskDelay(pdMS_TO_TICKS(300));
            int raw_off = read_current_sense_raw();
            ESP_LOGI(TAG, "%-8s -> OFF | current-sense raw ADC = %d", devices[i].name, raw_off);
            vTaskDelay(pdMS_TO_TICKS(500));
        }
    }
}
